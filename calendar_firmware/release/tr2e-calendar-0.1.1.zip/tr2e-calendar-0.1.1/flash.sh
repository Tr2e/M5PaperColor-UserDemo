#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then echo "Usage: bash flash.sh /dev/cu.usbmodemXXXX" >&2; exit 1; fi
release_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
flash_python="${TR2E_PYTHON:-python3}"
exec "$flash_python" -m esptool --chip esp32s3 --port "$1" --baud 460800 --before default_reset --after hard_reset write_flash --flash_mode dio --flash_freq 80m --flash_size 16MB 0x0 "$release_dir/bootloader.bin" 0x8000 "$release_dir/partition-table.bin" 0x10000 "$release_dir/tr2e_calendar.bin"
